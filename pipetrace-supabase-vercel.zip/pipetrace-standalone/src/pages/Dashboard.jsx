import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Plus, Search, ChevronRight, CheckCircle2, Clock, AlertCircle, Loader2 } from "lucide-react";
import { supabase } from "../lib/supabase";
import { calcLineProgress } from "../utils/ndt";

function ProgressRing({ pct, size = 44 }) {
  const r = (size - 6) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (pct / 100) * c;
  const color = pct === 100 ? "#10b981" : pct > 0 ? "#f59e0b" : "#cbd5e1";
  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#e2e8f0" strokeWidth={4} />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={4}
        strokeDasharray={c} strokeDashoffset={offset} strokeLinecap="round"
        style={{ transition: "stroke-dashoffset 0.5s ease" }} />
    </svg>
  );
}

const FORM_FIELDS = [
  { key: "line_number",       label: "N° Línea *",   req: true },
  { key: "isometric_number",  label: "N° Isométrico" },
  { key: "diameter",          label: "Diámetro" },
  { key: "schedule",          label: "Schedule" },
  { key: "material",          label: "Material" },
  { key: "fluid",             label: "Fluido" },
  { key: "welding_procedure", label: "WPS" },
  { key: "area",              label: "Área" },
];

export default function Dashboard() {
  const [lines,     setLines]     = useState([]);
  const [weldsMap,  setWeldsMap]  = useState({});
  const [loading,   setLoading]   = useState(true);
  const [search,    setSearch]    = useState("");
  const [showForm,  setShowForm]  = useState(false);
  const [form,      setForm]      = useState({});
  const [saving,    setSaving]    = useState(false);
  const [error,     setError]     = useState(null);

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const { data: linesData, error: lErr } = await supabase
        .from("piping_lines").select("*").order("created_at", { ascending: false });
      if (lErr) throw lErr;

      const { data: weldsData, error: wErr } = await supabase
        .from("welds").select("id, line_id, ndt_visual, ndt_gammagrafia, ndt_liquidos, ndt_termico, ndt_dureza, ndt_hidraulica, ndt_barrido");
      if (wErr) throw wErr;

      const map = {};
      weldsData.forEach(w => {
        if (!map[w.line_id]) map[w.line_id] = [];
        map[w.line_id].push(w);
      });

      setLines(linesData || []);
      setWeldsMap(map);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleCreate(e) {
    e.preventDefault();
    if (!form.line_number?.trim()) return;
    setSaving(true);
    try {
      const { error } = await supabase.from("piping_lines").insert({ ...form, status: "pendiente" });
      if (error) throw error;
      setShowForm(false);
      setForm({});
      load();
    } catch (e) {
      alert("Error: " + e.message);
    } finally {
      setSaving(false);
    }
  }

  const filtered = lines.filter(l =>
    [l.line_number, l.isometric_number, l.material, l.area]
      .some(v => v?.toLowerCase().includes(search.toLowerCase()))
  );

  const stats = {
    total:      lines.length,
    completas:  lines.filter(l => calcLineProgress(weldsMap[l.id]) === 100).length,
    proceso:    lines.filter(l => { const p = calcLineProgress(weldsMap[l.id]); return p > 0 && p < 100; }).length,
    pendientes: lines.filter(l => !weldsMap[l.id]?.length).length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Dashboard</h2>
          <p className="text-sm text-slate-500">Avance de Líneas de Cañería</p>
        </div>
        <button onClick={() => setShowForm(s => !s)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1e3a5f] text-white text-sm font-medium hover:bg-[#162d4a] transition-colors shrink-0">
          <Plus className="w-4 h-4" />
          Nueva Línea
        </button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Total",       value: stats.total,      color: "text-[#1e3a5f]" },
          { label: "Completadas", value: stats.completas,  color: "text-emerald-600" },
          { label: "En Proceso",  value: stats.proceso,    color: "text-amber-600" },
          { label: "Pendientes",  value: stats.pendientes, color: "text-slate-400" },
        ].map(k => (
          <div key={k.label} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">{k.label}</p>
            <p className={`text-3xl font-bold mt-1 ${k.color}`}>{k.value}</p>
          </div>
        ))}
      </div>

      {/* New line form */}
      {showForm && (
        <div className="rounded-xl border border-dashed border-[#1e3a5f]/30 bg-white p-5 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">Nueva Línea de Cañería</h3>
          <form onSubmit={handleCreate} className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {FORM_FIELDS.map(f => (
              <div key={f.key} className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">{f.label}</label>
                <input required={f.req} value={form[f.key] || ""}
                  onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                  className="w-full h-8 rounded-md border border-slate-200 px-3 text-sm bg-white
                    focus:outline-none focus:ring-2 focus:ring-[#1e3a5f]/30 focus:border-[#1e3a5f]" />
              </div>
            ))}
            <div className="col-span-full flex gap-2 mt-1">
              <button type="submit" disabled={saving}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1e3a5f] text-white text-sm font-medium
                  hover:bg-[#162d4a] disabled:opacity-50">
                {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
                {saving ? "Guardando..." : "Crear Línea"}
              </button>
              <button type="button" onClick={() => { setShowForm(false); setForm({}); }}
                className="px-4 py-2 rounded-lg border border-slate-200 text-sm font-medium hover:bg-slate-50">
                Cancelar
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Buscar por línea, isométrico, material, área..."
          className="w-full h-9 pl-9 pr-3 rounded-lg border border-slate-200 bg-white text-sm
            focus:outline-none focus:ring-2 focus:ring-[#1e3a5f]/30 focus:border-[#1e3a5f]" />
      </div>

      {/* Error */}
      {error && (
        <div className="rounded-lg bg-red-50 border border-red-200 p-4 text-sm text-red-700">
          Error al cargar datos: {error}
        </div>
      )}

      {/* Lines list */}
      {loading ? (
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => <div key={i} className="h-16 rounded-xl bg-slate-100 animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-12 text-center">
          <p className="text-slate-400 text-sm">No hay líneas registradas.</p>
          <p className="text-xs text-slate-400 mt-1">Creá la primera línea con el botón de arriba.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(line => {
            const lineWelds = weldsMap[line.id] || [];
            const pct = calcLineProgress(lineWelds);
            return (
              <Link key={line.id} to={`/linea/${line.id}`}>
                <div className="rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm
                  hover:shadow-md hover:border-[#1e3a5f]/30 transition-all flex items-center justify-between gap-4 group">
                  <div className="flex items-center gap-3 min-w-0">
                    <ProgressRing pct={pct} />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-800 truncate">
                          Línea {line.line_number}
                        </span>
                        {pct === 100 && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />}
                      </div>
                      <p className="text-xs text-slate-400 truncate">
                        {[line.isometric_number, line.diameter, line.material, line.area].filter(Boolean).join(" · ")}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="hidden sm:flex flex-col items-end">
                      <span className="text-xs text-slate-400">{lineWelds.length} juntas</span>
                      <span className={`text-xs font-bold ${pct === 100 ? "text-emerald-600" : pct > 0 ? "text-amber-600" : "text-slate-300"}`}>
                        {pct}%
                      </span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-[#1e3a5f] transition-colors" />
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
