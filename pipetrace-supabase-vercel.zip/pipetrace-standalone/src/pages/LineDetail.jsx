import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import {
  ArrowLeft, Plus, ChevronDown, ChevronUp, Trash2,
  FileText, Upload, Loader2, User, Pencil, Check, X
} from "lucide-react";
import { supabase, uploadFile } from "../lib/supabase";
import { NDT_TYPES, STATUS_CONFIG, calcWeldProgress } from "../utils/ndt";

// ─── NDT Stage Cell ──────────────────────────────────────────────────────────
function NdtCell({ ndt, weld, onUpdate }) {
  const [uploading, setUploading] = useState(false);
  const sk = weld[`ndt_${ndt.key}`] || "pendiente";
  const cfg = STATUS_CONFIG[sk];

  async function handleFile(e) {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      const url = await uploadFile(file);
      onUpdate({ [`ndt_${ndt.key}_report`]: url });
    } catch (err) { alert("Error subiendo archivo: " + err.message); }
    finally { setUploading(false); }
  }

  return (
    <div className="rounded-lg border border-slate-200 bg-white p-3 space-y-2">
      <div className="flex items-center justify-between gap-1">
        <span className="text-xs font-semibold text-slate-700 truncate">{ndt.label}</span>
        <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full border shrink-0 ${cfg.badge}`}>
          {cfg.label}
        </span>
      </div>

      <select value={sk}
        onChange={e => onUpdate({ [`ndt_${ndt.key}`]: e.target.value })}
        className="w-full h-7 rounded-md border border-slate-200 px-2 text-xs bg-white
          focus:outline-none focus:ring-1 focus:ring-[#1e3a5f]/40">
        {Object.entries(STATUS_CONFIG).map(([k, v]) => (
          <option key={k} value={k}>{v.label}</option>
        ))}
      </select>

      <input type="date" value={weld[`ndt_${ndt.key}_date`] || ""}
        onChange={e => onUpdate({ [`ndt_${ndt.key}_date`]: e.target.value })}
        className="w-full h-7 rounded-md border border-slate-200 px-2 text-xs bg-white
          focus:outline-none focus:ring-1 focus:ring-[#1e3a5f]/40" />

      {weld[`ndt_${ndt.key}_report`] ? (
        <div className="flex items-center gap-1">
          <a href={weld[`ndt_${ndt.key}_report`]} target="_blank" rel="noopener noreferrer"
            className="flex items-center gap-1 text-[11px] text-[#1e3a5f] hover:underline truncate">
            <FileText className="w-3 h-3 shrink-0" />Ver PDF
          </a>
          <button onClick={() => onUpdate({ [`ndt_${ndt.key}_report`]: null })}
            className="ml-auto text-red-400 hover:text-red-600 shrink-0">
            <X className="w-3 h-3" />
          </button>
        </div>
      ) : (
        <label className="relative cursor-pointer block">
          <input type="file" accept=".pdf" className="absolute inset-0 opacity-0 cursor-pointer w-full"
            disabled={uploading} onChange={handleFile} />
          <div className="flex items-center justify-center gap-1 h-7 rounded-md border border-dashed border-slate-300
            text-[11px] text-slate-400 hover:border-[#1e3a5f] hover:text-[#1e3a5f] transition-colors">
            {uploading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Upload className="w-3 h-3" />}
            {uploading ? "Subiendo..." : "PDF"}
          </div>
        </label>
      )}
    </div>
  );
}

// ─── Weld Row ────────────────────────────────────────────────────────────────
function WeldRow({ weld, welders, onRefresh }) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  async function update(patch) {
    setSaving(true);
    try {
      const { error } = await supabase.from("welds").update(patch).eq("id", weld.id);
      if (error) throw error;
      onRefresh();
    } finally { setSaving(false); }
  }

  async function handleDelete() {
    if (!confirm(`¿Eliminar junta ${weld.weld_number}?`)) return;
    await supabase.from("welds").delete().eq("id", weld.id);
    onRefresh();
  }

  async function handleWelder(welderId) {
    const w = welders.find(x => x.id === welderId);
    await update({ welder_id: welderId || null, welder_number: w?.welder_number || "" });
  }

  const pct = calcWeldProgress(weld);
  const hasRejected = NDT_TYPES.some(n => weld[`ndt_${n.key}`] === "rechazado");

  return (
    <div className={`rounded-xl border bg-white overflow-hidden ${open ? "shadow-md border-[#1e3a5f]/20" : "border-slate-200 shadow-sm"}`}>
      <button className="w-full text-left" onClick={() => setOpen(o => !o)}>
        <div className="flex items-center justify-between px-4 py-3 hover:bg-slate-50 transition-colors">
          <div className="flex items-center gap-3">
            <span className="text-sm font-bold text-slate-800 w-10 shrink-0">{weld.weld_number}</span>
            {weld.welder_number && (
              <span className="flex items-center gap-1 text-xs text-slate-400">
                <User className="w-3 h-3" />{weld.welder_number}
              </span>
            )}
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex gap-1">
              {NDT_TYPES.map(n => (
                <div key={n.key}
                  className={`w-2 h-2 rounded-full ${STATUS_CONFIG[weld[`ndt_${n.key}`] || "pendiente"]?.dot}`}
                  title={n.label} />
              ))}
            </div>
            <span className={`text-xs font-bold ${pct === 100 ? "text-emerald-600" : hasRejected ? "text-red-500" : "text-slate-400"}`}>
              {pct}%
            </span>
            {open ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
          </div>
        </div>
      </button>

      {open && (
        <div className="px-4 pb-4 border-t border-slate-100 space-y-4">
          <div className="flex items-center gap-3 pt-3">
            <User className="w-4 h-4 text-slate-400 shrink-0" />
            <span className="text-xs text-slate-400">Soldador:</span>
            <select value={weld.welder_id || ""}
              onChange={e => handleWelder(e.target.value)}
              className="h-7 w-48 rounded-md border border-slate-200 px-2 text-xs bg-white
                focus:outline-none focus:ring-1 focus:ring-[#1e3a5f]/40">
              <option value="">Sin asignar</option>
              {welders.map(w => (
                <option key={w.id} value={w.id}>
                  {w.welder_number}{w.full_name ? ` — ${w.full_name}` : ""}
                </option>
              ))}
            </select>
            <button onClick={handleDelete}
              className="ml-auto p-1.5 rounded-md hover:bg-red-50 text-red-400 hover:text-red-600 transition-colors">
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {NDT_TYPES.map(ndt => (
              <NdtCell key={ndt.key} ndt={ndt} weld={weld} onUpdate={update} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Main Page ───────────────────────────────────────────────────────────────
const LINE_FIELDS = [
  { key: "isometric_number",   label: "N° Isométrico" },
  { key: "revision",           label: "Revisión" },
  { key: "diameter",           label: "Diámetro" },
  { key: "schedule",           label: "Schedule" },
  { key: "material",           label: "Material" },
  { key: "fluid",              label: "Fluido" },
  { key: "design_pressure",    label: "P. Diseño" },
  { key: "design_temperature", label: "T. Diseño" },
  { key: "welding_procedure",  label: "WPS" },
  { key: "area",               label: "Área" },
  { key: "joint_count",        label: "N° Juntas" },
];

export default function LineDetail() {
  const { id } = useParams();
  const [line, setLine]       = useState(null);
  const [welds, setWelds]     = useState([]);
  const [welders, setWelders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState({});
  const [saving, setSaving]   = useState(false);
  const [newWeld, setNewWeld] = useState({ weld_number: "", welder_id: "" });
  const [addOpen, setAddOpen] = useState(false);
  const [addSaving, setAddSaving] = useState(false);

  useEffect(() => { load(); }, [id]);

  async function load() {
    setLoading(true);
    const [{ data: lineData }, { data: weldsData }, { data: weldersData }] = await Promise.all([
      supabase.from("piping_lines").select("*").eq("id", id).single(),
      supabase.from("welds").select("*").eq("line_id", id).order("weld_number"),
      supabase.from("welders").select("*").order("welder_number"),
    ]);
    setLine(lineData);
    setWelds(weldsData || []);
    setWelders(weldersData || []);
    setLoading(false);
  }

  async function handleSaveLine(e) {
    e.preventDefault();
    setSaving(true);
    await supabase.from("piping_lines").update(editForm).eq("id", id);
    setEditing(false);
    setSaving(false);
    load();
  }

  async function handleAddWeld(e) {
    e.preventDefault();
    if (!newWeld.weld_number.trim()) return;
    setAddSaving(true);
    const welder = welders.find(w => w.id === newWeld.welder_id);
    await supabase.from("welds").insert({
      line_id: id,
      weld_number: newWeld.weld_number.trim().toUpperCase(),
      welder_id: newWeld.welder_id || null,
      welder_number: welder?.welder_number || "",
    });
    setNewWeld({ weld_number: "", welder_id: "" });
    setAddOpen(false);
    setAddSaving(false);
    load();
  }

  if (loading) return (
    <div className="space-y-4 animate-pulse">
      <div className="h-8 w-48 bg-slate-100 rounded" />
      <div className="h-48 bg-slate-100 rounded-xl" />
    </div>
  );

  if (!line) return (
    <div className="text-center py-20">
      <p className="text-slate-400">Línea no encontrada</p>
      <Link to="/"><button className="mt-4 px-4 py-2 rounded-lg border text-sm hover:bg-slate-50">Volver</button></Link>
    </div>
  );

  const sorted = [...welds].sort((a, b) =>
    (parseInt(a.weld_number.replace(/\D/g,""))||0) - (parseInt(b.weld_number.replace(/\D/g,""))||0));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Link to="/"><button className="p-2 rounded-lg hover:bg-slate-100 transition-colors"><ArrowLeft className="w-4 h-4" /></button></Link>
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Línea {line.line_number}</h2>
            {line.isometric_number && <p className="text-sm text-slate-400">Isométrico: {line.isometric_number}</p>}
          </div>
        </div>
        <button onClick={() => { setEditing(e => !e); setEditForm(line); }}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 text-sm font-medium hover:bg-slate-50">
          {editing ? <X className="w-3.5 h-3.5" /> : <Pencil className="w-3.5 h-3.5" />}
          {editing ? "Cancelar" : "Editar"}
        </button>
      </div>

      {/* Line data */}
      {editing ? (
        <form onSubmit={handleSaveLine} className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm space-y-4">
          <h3 className="text-sm font-semibold text-slate-700">Editar datos del Isométrico</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {LINE_FIELDS.map(f => (
              <div key={f.key} className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">{f.label}</label>
                <input value={editForm[f.key] || ""}
                  onChange={e => setEditForm(p => ({ ...p, [f.key]: e.target.value }))}
                  className="w-full h-8 rounded-md border border-slate-200 px-3 text-sm bg-white
                    focus:outline-none focus:ring-2 focus:ring-[#1e3a5f]/30" />
              </div>
            ))}
            <div className="col-span-full space-y-1">
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Observaciones</label>
              <textarea value={editForm.notes || ""} rows={2}
                onChange={e => setEditForm(p => ({ ...p, notes: e.target.value }))}
                className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm bg-white
                  focus:outline-none focus:ring-2 focus:ring-[#1e3a5f]/30" />
            </div>
          </div>
          <button type="submit" disabled={saving}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1e3a5f] text-white text-sm font-medium
              hover:bg-[#162d4a] disabled:opacity-50">
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
            Guardar
          </button>
        </form>
      ) : (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-3">Datos del Isométrico</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {LINE_FIELDS.map(f => (
              <div key={f.key}>
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">{f.label}</p>
                <p className="text-sm font-medium text-slate-700 mt-0.5">{line[f.key] || "—"}</p>
              </div>
            ))}
          </div>
          {line.isometric_pdf_url && (
            <div className="mt-4 pt-4 border-t border-slate-100">
              <a href={line.isometric_pdf_url} target="_blank" rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-xs text-[#1e3a5f] hover:underline
                  border border-[#1e3a5f]/20 rounded-lg px-3 py-1.5 bg-[#1e3a5f]/5">
                <FileText className="w-3.5 h-3.5" />Ver PDF del Isométrico
              </a>
            </div>
          )}
          {line.notes && (
            <div className="mt-3 pt-3 border-t border-slate-100">
              <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Observaciones</p>
              <p className="text-sm text-slate-500 mt-0.5">{line.notes}</p>
            </div>
          )}
        </div>
      )}

      {/* Welds */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-slate-800">Juntas de Soldadura</h3>
            <p className="text-xs text-slate-400">{welds.length} junta{welds.length !== 1 ? "s" : ""}</p>
          </div>
          <button onClick={() => setAddOpen(o => !o)} disabled={welds.length >= 100}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium hover:bg-slate-50 disabled:opacity-40">
            {addOpen ? <X className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
            {addOpen ? "Cancelar" : "Agregar Junta"}
          </button>
        </div>

        {addOpen && (
          <form onSubmit={handleAddWeld}
            className="rounded-xl border border-dashed border-[#1e3a5f]/30 bg-white p-4 flex flex-wrap items-end gap-3">
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">N° Junta *</label>
              <input required maxLength={6} value={newWeld.weld_number}
                onChange={e => setNewWeld(p => ({ ...p, weld_number: e.target.value }))}
                placeholder="Ej: C1"
                className="w-28 h-8 rounded-md border border-slate-200 px-3 text-sm bg-white
                  focus:outline-none focus:ring-2 focus:ring-[#1e3a5f]/30" />
            </div>
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Soldador</label>
              <select value={newWeld.welder_id}
                onChange={e => setNewWeld(p => ({ ...p, welder_id: e.target.value }))}
                className="h-8 w-44 rounded-md border border-slate-200 px-2 text-sm bg-white
                  focus:outline-none focus:ring-2 focus:ring-[#1e3a5f]/30">
                <option value="">Sin asignar</option>
                {welders.map(w => (
                  <option key={w.id} value={w.id}>
                    {w.welder_number}{w.full_name ? ` — ${w.full_name}` : ""}
                  </option>
                ))}
              </select>
            </div>
            <button type="submit" disabled={addSaving}
              className="flex items-center gap-1.5 h-8 px-4 rounded-lg bg-[#1e3a5f] text-white text-sm font-medium
                hover:bg-[#162d4a] disabled:opacity-50">
              {addSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
              Agregar
            </button>
          </form>
        )}

        {sorted.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
            <p className="text-sm text-slate-400">No hay juntas registradas.</p>
            <p className="text-xs text-slate-400 mt-1">Agregá juntas para hacer el seguimiento de ensayos NDT.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {sorted.map(w => <WeldRow key={w.id} weld={w} welders={welders} onRefresh={load} />)}
          </div>
        )}
      </div>
    </div>
  );
}
