import { useState, useEffect } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import { supabase } from "../lib/supabase";
import { NDT_TYPES, STATUS_CONFIG, calcWeldProgress, calcLineProgress } from "../utils/ndt";

export default function Analitica() {
  const [lines, setLines]   = useState([]);
  const [welds, setWelds]   = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [{ data: l }, { data: w }] = await Promise.all([
        supabase.from("piping_lines").select("*"),
        supabase.from("welds").select("*"),
      ]);
      setLines(l || []);
      setWelds(w || []);
      setLoading(false);
    }
    load();
  }, []);

  const weldsFor = lineId => welds.filter(w => w.line_id === lineId);

  const lineProgress = lines.map(l => ({
    name: `L-${l.line_number}`,
    avance: calcLineProgress(weldsFor(l.id)),
  }));

  const ndtTable = NDT_TYPES.map(ndt => {
    const applicable = welds.filter(w => w[`ndt_${ndt.key}`] !== "no_aplica");
    const counts = {};
    Object.keys(STATUS_CONFIG).forEach(s => {
      counts[s] = applicable.filter(w => (w[`ndt_${ndt.key}`] || "pendiente") === s).length;
    });
    return { ...ndt, ...counts, total: applicable.length };
  });

  const welderMap = {};
  welds.forEach(w => {
    const k = w.welder_number || "Sin asignar";
    if (!welderMap[k]) welderMap[k] = { name: k, total: 0, aprobadas: 0 };
    welderMap[k].total++;
    if (calcWeldProgress(w) === 100) welderMap[k].aprobadas++;
  });
  const welderData = Object.values(welderMap).sort((a,b) => b.total - a.total).slice(0, 10);

  const pie = [
    { name: "Completadas", value: lines.filter(l => calcLineProgress(weldsFor(l.id)) === 100).length, color: "#10b981" },
    { name: "En Proceso",  value: lines.filter(l => { const p = calcLineProgress(weldsFor(l.id)); return p > 0 && p < 100; }).length, color: "#f59e0b" },
    { name: "Sin Iniciar", value: lines.filter(l => calcLineProgress(weldsFor(l.id)) === 0).length, color: "#e2e8f0" },
  ].filter(d => d.value > 0);

  const totalApproved = welds.filter(w => calcWeldProgress(w) === 100).length;
  const globalPct = welds.length ? Math.round(totalApproved / welds.length * 100) : 0;

  if (loading) return (
    <div className="space-y-4 animate-pulse">
      {[...Array(3)].map((_,i) => <div key={i} className="h-48 rounded-xl bg-slate-100" />)}
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-800">Analítica</h2>
        <p className="text-sm text-slate-400">Análisis y métricas del proyecto</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Líneas",          value: lines.length,   color: "text-[#1e3a5f]" },
          { label: "Juntas",          value: welds.length,   color: "text-slate-700" },
          { label: "Juntas Aprobadas",value: totalApproved,  color: "text-emerald-600" },
          { label: "Avance Global",   value: `${globalPct}%`,color: globalPct===100 ? "text-emerald-600" : "text-amber-600" },
        ].map(k => (
          <div key={k.label} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">{k.label}</p>
            <p className={`text-3xl font-bold mt-1 ${k.color}`}>{k.value}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        {/* Avance por línea */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">Avance por Línea (%)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={lineProgress} margin={{ left: -20, right: 10 }}>
              <XAxis dataKey="name" tick={{ fontSize: 10 }} />
              <YAxis domain={[0,100]} tick={{ fontSize: 10 }} unit="%" />
              <Tooltip formatter={v => [`${v}%`, "Avance"]} contentStyle={{ fontSize: 12, borderRadius: 8 }} />
              <Bar dataKey="avance" fill="#1e3a5f" radius={[4,4,0,0]} maxBarSize={40} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Estado líneas pie */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">Estado de Líneas</h3>
          {pie.length === 0
            ? <p className="text-xs text-slate-400 text-center py-8">Sin datos</p>
            : <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={pie} cx="50%" cy="50%" outerRadius={80} dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent*100).toFixed(0)}%`}
                    labelLine={false} style={{ fontSize: 11 }}>
                    {pie.map((d, i) => <Cell key={i} fill={d.color} />)}
                  </Pie>
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                </PieChart>
              </ResponsiveContainer>
          }
        </div>

        {/* NDT table */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm lg:col-span-2">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">Estado de los 7 Ensayos NDT por Junta</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-slate-100">
                  <th className="text-left py-2 pr-4 font-semibold text-slate-400">Ensayo</th>
                  {Object.entries(STATUS_CONFIG).map(([k, v]) => (
                    <th key={k} className="text-center py-2 px-2 font-semibold text-slate-400">{v.label}</th>
                  ))}
                  <th className="text-center py-2 px-2 font-semibold text-slate-400">Total</th>
                </tr>
              </thead>
              <tbody>
                {ndtTable.map(row => (
                  <tr key={row.key} className="border-b border-slate-50 hover:bg-slate-50 last:border-0">
                    <td className="py-2 pr-4 font-medium text-slate-700">{row.label}</td>
                    {Object.keys(STATUS_CONFIG).map(s => (
                      <td key={s} className="py-2 px-2 text-center">
                        <span className={`font-semibold ${
                          s==="aprobado" ? "text-emerald-600" : s==="rechazado" ? "text-red-500" :
                          s==="en_proceso" ? "text-amber-600" : "text-slate-300"}`}>
                          {row[s] || 0}
                        </span>
                      </td>
                    ))}
                    <td className="py-2 px-2 text-center font-semibold text-slate-400">{row.total}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Soldadores */}
        {welderData.length > 0 && (
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm lg:col-span-2">
            <h3 className="text-sm font-semibold text-slate-700 mb-4">Soldaduras por Soldador</h3>
            <ResponsiveContainer width="100%" height={Math.max(160, welderData.length * 28)}>
              <BarChart data={welderData} layout="vertical" margin={{ left: 60, right: 20 }}>
                <XAxis type="number" tick={{ fontSize: 10 }} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 10 }} width={60} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Bar dataKey="total"     name="Total"     fill="#1e3a5f" radius={[0,4,4,0]} />
                <Bar dataKey="aprobadas" name="Aprobadas" fill="#10b981" radius={[0,4,4,0]} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </div>
  );
}
