import { useState, useEffect } from "react";
import { HardHat, Plus, Trash2, Pencil, Check, X, FileText, Upload, Loader2 } from "lucide-react";
import { supabase, uploadFile } from "../lib/supabase";

const PROCESSES = ["SMAW", "GTAW", "GMAW", "FCAW", "SAW", "OTRO"];

function WelderCard({ welder, onRefresh }) {
  const [editing, setEditing]     = useState(false);
  const [form, setForm]           = useState(welder);
  const [saving, setSaving]       = useState(false);
  const [uploading, setUploading] = useState(false);

  async function handleSave() {
    setSaving(true);
    await supabase.from("welders").update(form).eq("id", welder.id);
    setSaving(false);
    setEditing(false);
    onRefresh();
  }

  async function handleDelete() {
    if (!confirm(`¿Eliminar soldador ${welder.welder_number}?`)) return;
    await supabase.from("welders").delete().eq("id", welder.id);
    onRefresh();
  }

  async function handleFile(e) {
    const file = e.target.files[0]; if (!file) return;
    setUploading(true);
    try {
      const url = await uploadFile(file, "certificates");
      setForm(p => ({ ...p, certificate_url: url }));
    } finally { setUploading(false); }
  }

  const expired = welder.certification_expiry && new Date(welder.certification_expiry) < new Date();

  if (editing) return (
    <div className="rounded-xl border border-[#1e3a5f]/20 bg-white p-4 shadow-sm space-y-3">
      <div className="grid grid-cols-2 gap-3">
        {[
          { key: "welder_number", label: "N° Soldador *", req: true },
          { key: "full_name",     label: "Nombre Completo" },
          { key: "certification", label: "Certificación" },
        ].map(f => (
          <div key={f.key} className="space-y-1">
            <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">{f.label}</label>
            <input required={f.req} value={form[f.key] || ""}
              onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
              className="w-full h-8 rounded-md border border-slate-200 px-3 text-sm bg-white
                focus:outline-none focus:ring-2 focus:ring-[#1e3a5f]/30" />
          </div>
        ))}
        <div className="space-y-1">
          <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Proceso</label>
          <select value={form.process || ""}
            onChange={e => setForm(p => ({ ...p, process: e.target.value }))}
            className="w-full h-8 rounded-md border border-slate-200 px-2 text-sm bg-white
              focus:outline-none focus:ring-2 focus:ring-[#1e3a5f]/30">
            <option value="">—</option>
            {PROCESSES.map(p => <option key={p} value={p}>{p}</option>)}
          </select>
        </div>
        <div className="space-y-1 col-span-2">
          <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Vencimiento Certificado</label>
          <input type="date" value={form.certification_expiry || ""}
            onChange={e => setForm(p => ({ ...p, certification_expiry: e.target.value }))}
            className="w-full h-8 rounded-md border border-slate-200 px-3 text-sm bg-white
              focus:outline-none focus:ring-2 focus:ring-[#1e3a5f]/30" />
        </div>
        <div className="space-y-1 col-span-2">
          <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Certificado (PDF)</label>
          {form.certificate_url ? (
            <div className="flex items-center gap-2">
              <a href={form.certificate_url} target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-1 text-xs text-[#1e3a5f] hover:underline">
                <FileText className="w-3 h-3" />Ver PDF actual
              </a>
              <button type="button" onClick={() => setForm(p => ({ ...p, certificate_url: null }))}
                className="text-red-400 hover:text-red-600"><X className="w-3 h-3" /></button>
            </div>
          ) : (
            <label className="relative cursor-pointer block">
              <input type="file" accept=".pdf" className="absolute inset-0 opacity-0 w-full cursor-pointer"
                disabled={uploading} onChange={handleFile} />
              <div className="flex items-center gap-1 h-8 px-3 rounded-md border border-dashed border-slate-300
                text-xs text-slate-400 hover:border-[#1e3a5f] hover:text-[#1e3a5f] transition-colors">
                {uploading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Upload className="w-3 h-3" />}
                {uploading ? "Subiendo..." : "Subir certificado"}
              </div>
            </label>
          )}
        </div>
      </div>
      <div className="flex gap-2">
        <button onClick={handleSave} disabled={saving}
          className="flex items-center gap-1.5 h-8 px-3 rounded-lg bg-[#1e3a5f] text-white text-xs font-medium
            hover:bg-[#162d4a] disabled:opacity-50">
          {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />}
          Guardar
        </button>
        <button onClick={() => { setEditing(false); setForm(welder); }}
          className="h-8 px-3 rounded-lg border border-slate-200 text-xs font-medium hover:bg-slate-50">
          Cancelar
        </button>
      </div>
    </div>
  );

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm flex items-start justify-between gap-3">
      <div className="space-y-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-bold text-sm text-slate-800">{welder.welder_number}</span>
          {welder.process && (
            <span className="text-[10px] bg-[#1e3a5f]/10 text-[#1e3a5f] px-2 py-0.5 rounded-full font-medium">
              {welder.process}
            </span>
          )}
          {expired && (
            <span className="text-[10px] bg-red-50 text-red-600 border border-red-200 px-2 py-0.5 rounded-full font-medium">
              Cert. Vencida
            </span>
          )}
        </div>
        {welder.full_name && <p className="text-sm text-slate-600">{welder.full_name}</p>}
        {welder.certification && <p className="text-xs text-slate-400">Cert: {welder.certification}</p>}
        {welder.certification_expiry && (
          <p className={`text-xs ${expired ? "text-red-500 font-medium" : "text-slate-400"}`}>
            Vence: {new Date(welder.certification_expiry).toLocaleDateString("es-AR")}
          </p>
        )}
        {welder.certificate_url && (
          <a href={welder.certificate_url} target="_blank" rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs text-[#1e3a5f] hover:underline">
            <FileText className="w-3 h-3" />Certificado Vigente (PDF)
          </a>
        )}
      </div>
      <div className="flex items-center gap-1 shrink-0">
        <button onClick={() => { setEditing(true); setForm(welder); }}
          className="p-1.5 rounded-md hover:bg-slate-100 text-slate-400 transition-colors">
          <Pencil className="w-3.5 h-3.5" />
        </button>
        <button onClick={handleDelete}
          className="p-1.5 rounded-md hover:bg-red-50 text-red-400 hover:text-red-600 transition-colors">
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}

export default function Soldadores() {
  const [welders, setWelders]   = useState([]);
  const [loading, setLoading]   = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm]         = useState({ welder_number: "", full_name: "", process: "" });
  const [saving, setSaving]     = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("welders").select("*").order("welder_number");
    setWelders(data || []);
    setLoading(false);
  }

  async function handleCreate(e) {
    e.preventDefault();
    if (!form.welder_number.trim()) return;
    setSaving(true);
    await supabase.from("welders").insert({ ...form, active: true });
    setForm({ welder_number: "", full_name: "", process: "" });
    setShowForm(false);
    setSaving(false);
    load();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Soldadores</h2>
          <p className="text-sm text-slate-400">{welders.length} soldador{welders.length !== 1 ? "es" : ""} registrado{welders.length !== 1 ? "s" : ""}</p>
        </div>
        <button onClick={() => setShowForm(s => !s)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1e3a5f] text-white text-sm font-medium hover:bg-[#162d4a] shrink-0">
          <Plus className="w-4 h-4" />Nuevo Soldador
        </button>
      </div>

      {showForm && (
        <div className="rounded-xl border border-dashed border-[#1e3a5f]/30 bg-white p-5 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">Nuevo Soldador</h3>
          <form onSubmit={handleCreate} className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {[
              { key: "welder_number", label: "N° Soldador *", req: true },
              { key: "full_name",     label: "Nombre Completo" },
              { key: "certification", label: "Certificación" },
            ].map(f => (
              <div key={f.key} className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">{f.label}</label>
                <input required={f.req} value={form[f.key] || ""}
                  onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                  className="w-full h-8 rounded-md border border-slate-200 px-3 text-sm bg-white
                    focus:outline-none focus:ring-2 focus:ring-[#1e3a5f]/30" />
              </div>
            ))}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Proceso</label>
              <select value={form.process || ""}
                onChange={e => setForm(p => ({ ...p, process: e.target.value }))}
                className="w-full h-8 rounded-md border border-slate-200 px-2 text-sm bg-white
                  focus:outline-none focus:ring-2 focus:ring-[#1e3a5f]/30">
                <option value="">—</option>
                {PROCESSES.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div className="col-span-full flex gap-2 mt-1">
              <button type="submit" disabled={saving}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1e3a5f] text-white text-sm font-medium hover:bg-[#162d4a] disabled:opacity-50">
                {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
                {saving ? "Guardando..." : "Crear Soldador"}
              </button>
              <button type="button" onClick={() => setShowForm(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-sm font-medium hover:bg-slate-50">
                Cancelar
              </button>
            </div>
          </form>
        </div>
      )}

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[...Array(6)].map((_, i) => <div key={i} className="h-24 rounded-xl bg-slate-100 animate-pulse" />)}
        </div>
      ) : welders.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-12 text-center">
          <HardHat className="w-10 h-10 text-slate-200 mx-auto mb-3" />
          <p className="text-sm text-slate-400">No hay soldadores registrados.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {welders.map(w => <WelderCard key={w.id} welder={w} onRefresh={load} />)}
        </div>
      )}
    </div>
  );
}
