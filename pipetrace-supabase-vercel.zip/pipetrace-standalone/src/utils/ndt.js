export const NDT_TYPES = [
  { key: "visual",      label: "Inspección Visual",    abbr: "VIS" },
  { key: "gammagrafia", label: "Gammagrafía",           abbr: "GAM" },
  { key: "liquidos",    label: "Líquidos Penetrantes",  abbr: "LP"  },
  { key: "termico",     label: "Tratamiento Térmico",   abbr: "TT"  },
  { key: "dureza",      label: "Dureza",                abbr: "DUR" },
  { key: "hidraulica",  label: "Prueba Hidráulica",     abbr: "HID" },
  { key: "barrido",     label: "Barrido",               abbr: "BAR" },
];

export const STATUS_CONFIG = {
  pendiente:  { label: "Pendiente",  dot: "bg-slate-300",   badge: "bg-slate-100 text-slate-600 border-slate-200" },
  en_proceso: { label: "En Proceso", dot: "bg-amber-400",   badge: "bg-amber-50 text-amber-700 border-amber-200" },
  aprobado:   { label: "Aprobado",   dot: "bg-emerald-500", badge: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  rechazado:  { label: "Rechazado",  dot: "bg-red-500",     badge: "bg-red-50 text-red-700 border-red-200" },
  no_aplica:  { label: "No Aplica",  dot: "bg-gray-200",    badge: "bg-gray-50 text-gray-400 border-gray-200" },
};

export function calcWeldProgress(weld) {
  const applicable = NDT_TYPES.filter(n => weld[`ndt_${n.key}`] !== "no_aplica");
  if (!applicable.length) return 100;
  const approved = applicable.filter(n => weld[`ndt_${n.key}`] === "aprobado").length;
  return Math.round((approved / applicable.length) * 100);
}

export function calcLineProgress(welds = []) {
  if (!welds.length) return 0;
  const sum = welds.reduce((acc, w) => acc + calcWeldProgress(w), 0);
  return Math.round(sum / welds.length);
}
