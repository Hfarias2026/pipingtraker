import { useState } from "react";
import { Link, useLocation, Outlet } from "react-router-dom";
import { LayoutDashboard, HardHat, BarChart2, Users, Menu, X } from "lucide-react";

const NAV = [
  { to: "/",            label: "Dashboard",  Icon: LayoutDashboard },
  { to: "/soldadores",  label: "Soldadores", Icon: HardHat },
  { to: "/analitica",   label: "Analítica",  Icon: BarChart2 },
];

export default function Layout() {
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 font-inter">
      <header className="sticky top-0 z-50 bg-[#1e3a5f] text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14">
            <Link to="/" className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-xs font-bold text-white">
                PT
              </div>
              <div className="hidden sm:block">
                <p className="text-sm font-bold leading-none">Piping Tracker</p>
                <p className="text-[10px] text-white/50 mt-0.5">Trazabilidad de Construcción</p>
              </div>
            </Link>

            <nav className="hidden md:flex items-center gap-1">
              {NAV.map(({ to, label, Icon }) => (
                <Link key={to} to={to}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium transition-colors
                    ${pathname === to
                      ? "bg-white/15 text-white"
                      : "text-white/60 hover:text-white hover:bg-white/10"}`}>
                  <Icon className="w-4 h-4" />{label}
                </Link>
              ))}
            </nav>

            <button className="md:hidden p-2 rounded-md hover:bg-white/10"
              onClick={() => setOpen(o => !o)}>
              {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {open && (
          <div className="md:hidden border-t border-white/10 px-4 pb-3">
            {NAV.map(({ to, label, Icon }) => (
              <Link key={to} to={to} onClick={() => setOpen(false)}
                className="flex items-center gap-2 px-3 py-2 mt-1 rounded-md text-sm text-white/70 hover:text-white hover:bg-white/10">
                <Icon className="w-4 h-4" />{label}
              </Link>
            ))}
          </div>
        )}
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        <Outlet />
      </main>
    </div>
  );
}
